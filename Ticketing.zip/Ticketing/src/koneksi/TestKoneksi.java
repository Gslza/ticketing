
package koneksi;

import koneksi.Koneksi;

public class TestKoneksi {
    public static void main(String[] args) {
        Koneksi.getConnection();
    }
}
